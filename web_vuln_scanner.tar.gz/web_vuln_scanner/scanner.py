import socket
import requests
import nmap
from urllib.parse import urlparse
from jinja2 import Environment, FileSystemLoader

def clean_target(user_input: str):
    """
    Normalize user input to extract clean hostname for scanning.
    Examples:
      http://testphp.vulnweb.com/ -> testphp.vulnweb.com
      https://demo.testfire.net   -> demo.testfire.net
      testphp.vulnweb.com/        -> testphp.vulnweb.com
    """
    user_input = user_input.strip()

    if user_input.startswith("http://") or user_input.startswith("https://"):
        parsed = urlparse(user_input)
        return parsed.netloc.strip("/"), parsed.scheme
    else:
        return user_input.strip("/"), "http"  # default to http


def port_scan(target):
    nm = nmap.PortScanner()
    try:
        print(f"[+] Scanning ports on {target}...")
        nm.scan(target, '1-1024')
    except Exception as e:
        print(f"[!] Error scanning {target}: {e}")
        return []

    if target not in nm.all_hosts():
        print(f"[!] No results found for {target}. Host may be down or blocked.")
        return []

    ports = []
    for proto in nm[target].all_protocols():
        lport = nm[target][proto].keys()
        for port in lport:
            state = nm[target][proto][port]['state']
            ports.append((port, state))
    return ports


def http_headers(target, scheme="http"):
    try:
        url = f"{scheme}://{target}"
        print(f"[+] Fetching HTTP headers from {url} ...")
        response = requests.get(url, timeout=5, allow_redirects=True)
        return dict(response.headers)
    except Exception as e:
        return {"error": str(e)}


def generate_report(target, ports, headers):
    env = Environment(loader=FileSystemLoader('templates'))
    template = env.get_template('report.html.j2')

    report_content = template.render(
        target=target,
        ports=ports,
        headers=headers
    )

    with open("report.html", "w", encoding="utf-8") as f:
        f.write(report_content)

    print("[+] Report saved as report.html")


if __name__ == "__main__":
    raw_target = input("Enter website (example.com): ").strip()
    target, scheme = clean_target(raw_target)

    ports = port_scan(target)
    headers = http_headers(target, scheme)

    generate_report(target, ports, headers)

